#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# STB_UNION E2 - Season/Episode Screen
#

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.MenuList import MenuList
from enigma import eTimer

from .ServerConfig import SERVER_TYPE_STALKER, SERVER_TYPE_XTREAM
from .PlayerScreen import PlayerScreen


class SeasonScreen(Screen):
    """Seasons and Episodes browser for TV Series"""

    PAGE_SIZE = 15

    skin = """
        <screen name="SeasonScreen" position="0,0" size="1920,1080"
                flags="wfNoBorder" backgroundColor="#000000">
            <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/STB_UNION E2/skin/ChLive.png"
                     position="0,0" size="1920,1080" zPosition="-1" transparent="1"/>
            
            <widget name="series_title" position="100,180" size="1720,60"
                    font="Regular;32" foregroundColor="#ffdd00"
                    backgroundColor="transparent" halign="center" zPosition="2" transparent="1"/>
            
            <widget name="season_list" position="100,260" size="820,500"
                    scrollbarMode="showOnDemand" backgroundColor="#0a0060"
                    foregroundColor="#ffffff" font="Regular;24"
                    itemHeight="40" zPosition="2" transparent="1"/>
            
            <widget name="episode_list" position="1000,260" size="820,500"
                    scrollbarMode="showOnDemand" backgroundColor="#0a0060"
                    foregroundColor="#ffffff" font="Regular;24"
                    itemHeight="40" zPosition="2" transparent="1"/>

                    
            
            <widget name="season_info" position="100,770" size="820,40"
                    font="Regular;20" foregroundColor="#ffdd00"
                    backgroundColor="transparent" halign="center" zPosition="2" transparent="1"/>
            
            <widget name="episode_info" position="1000,770" size="820,40"
                    font="Regular;20" foregroundColor="#ffdd00"
                    backgroundColor="transparent" halign="center" zPosition="2" transparent="1"/>
            
            <widget name="status" position="100,720" size="1720,40"
                    font="Regular;24" foregroundColor="#10e02f"
                    backgroundColor="transparent" halign="center" valign="center"
                    zPosition="2" transparent="1"/>
            
            <widget name="hint_bar" position="0,1042" size="1920,38"
                    font="Regular;18" foregroundColor="#888888"
                    backgroundColor="transparent" halign="center" zPosition="2" transparent="1"/>
        </screen>
    """

    def __init__(self, session, config, server, series_title, series_id, api):
        Screen.__init__(self, session)
        self.session = session
        self.config = config
        self.server = server
        self.series_title = series_title
        self.series_id = series_id
        self._api = api
        self._seasons = []
        self._current_season_index = 0
        self._episodes = []
        self._current_episode_index = 0
        self._error_timer = None
        self._focused_panel = "seasons"

        self["series_title"] = Label(series_title)
        self["season_list"] = MenuList([])
        self["episode_list"] = MenuList([])
        self["season_info"] = Label("")
        self["episode_info"] = Label("")
        self["status"] = Label("")
        self["hint_bar"] = Label("LEFT/RIGHT=Switch panel  UP/DOWN=Navigate  OK=Play Episode  EXIT=Back")

        self["actions"] = ActionMap(
            ["OkCancelActions", "DirectionActions", "MovementActions"],
            {
                "ok": self.on_play,
                "cancel": self.on_back,
                "up": self.nav_up,
                "down": self.nav_down,
                "left": self.focus_left,
                "right": self.focus_right,
            }, -1
        )

        self.onLayoutFinish.append(self._load_seasons)

    def _load_seasons(self):
        """Load seasons for the series"""
        self["status"].setText("Loading seasons...")
        
        try:
            stype = self.server.get("type")
            
            if stype == SERVER_TYPE_XTREAM:
                seasons_data = self._api.get_series_seasons(self.series_id)
                if seasons_data:
                    self._seasons = seasons_data
                else:
                    # Try alternative method
                    info = self._api.get_series_info(self.series_id)
                    if info and "seasons" in info:
                        self._seasons = info["seasons"]
                    else:
                        self._seasons = []
                        
            elif stype == SERVER_TYPE_STALKER:
                seasons_data = self._api.get_series_seasons(self.series_id)
                if seasons_data:
                    self._seasons = seasons_data
                else:
                    self._seasons = []
            else:
                self._show_error_deferred("Unsupported server type")
                return
                
        except Exception as e:
            print("[STB_UNION E2] Error loading seasons: {}".format(e))
            self._seasons = []
        
        if not self._seasons:
            self._show_error_deferred("No seasons found for this series")
            return
            
        self._show_seasons()
        self._load_episodes(0)

    def _show_seasons(self):
        """Display seasons list"""
        display_items = []
        for idx, season in enumerate(self._seasons):
            season_num = season.get("season_number", idx + 1)
            season_name = season.get("name", "Season {}".format(season_num))
            display_items.append((season_name, season))
        
        self["season_list"].setList(display_items)
        if display_items:
            self["season_list"].setCurrentIndex(min(self._current_season_index, len(display_items) - 1))
            self._update_season_status()

    def _load_episodes(self, season_index):
        """Load episodes for selected season"""
        if season_index >= len(self._seasons):
            return
        
        self._current_season_index = season_index
        season = self._seasons[season_index]
        season_id = season.get("id", season.get("season_number", season_index + 1))
        season_num = season.get("season_number", season_index + 1)
        
        self["status"].setText("Loading episodes for Season {}...".format(season_num))
        
        try:
            stype = self.server.get("type")
            
            if stype == SERVER_TYPE_XTREAM:
                episodes_data = self._api.get_series_episodes(self.series_id, season_id)
                if episodes_data:
                    self._episodes = episodes_data
                else:
                    self._episodes = []
                    
            elif stype == SERVER_TYPE_STALKER:
                episodes_data = self._api.get_series_episodes(self.series_id, season_id)
                if episodes_data:
                    self._episodes = episodes_data
                else:
                    self._episodes = []
            else:
                self._episodes = []
                
        except Exception as e:
            print("[STB_UNION E2] Error loading episodes: {}".format(e))
            self._episodes = []
        
        self._show_episodes()
        self._update_season_status()

    def _show_episodes(self):
        """Display episodes list"""
        display_items = []
        for idx, episode in enumerate(self._episodes):
            episode_num = episode.get("episode_num", episode.get("number", idx + 1))
            episode_name = episode.get("name", episode.get("title", "Episode {}".format(episode_num)))
            display_items.append(("Episode {}: {}".format(episode_num, episode_name), episode))
        
        self["episode_list"].setList(display_items)
        if display_items:
            self["episode_list"].setCurrentIndex(min(self._current_episode_index, len(display_items) - 1))
            self._update_episode_status()

    def _update_season_status(self):
        """Update season info display"""
        if self._current_season_index < len(self._seasons):
            season = self._seasons[self._current_season_index]
            season_num = season.get("season_number", self._current_season_index + 1)
            self["season_info"].setText("Season {} - {} episodes".format(season_num, len(self._episodes)))

    def _update_episode_status(self):
        """Update episode info display"""
        sel = self["episode_list"].getCurrent()
        if sel:
            self["episode_info"].setText(sel[0])

    def nav_up(self):
        """Navigate up in focused panel"""
        if self._focused_panel == "seasons":
            idx = self["season_list"].getCurrentIndex()
            if idx > 0:
                self["season_list"].setCurrentIndex(idx - 1)
                self._load_episodes(idx - 1)
                self._current_episode_index = 0
        else:
            idx = self["episode_list"].getCurrentIndex()
            if idx > 0:
                self["episode_list"].setCurrentIndex(idx - 1)
                self._update_episode_status()

    def nav_down(self):
        """Navigate down in focused panel"""
        if self._focused_panel == "seasons":
            idx = self["season_list"].getCurrentIndex()
            last = len(self["season_list"].list) - 1
            if idx < last:
                self["season_list"].setCurrentIndex(idx + 1)
                self._load_episodes(idx + 1)
                self._current_episode_index = 0
        else:
            idx = self["episode_list"].getCurrentIndex()
            last = len(self["episode_list"].list) - 1
            if idx < last:
                self["episode_list"].setCurrentIndex(idx + 1)
                self._update_episode_status()

    def focus_left(self):
        """Focus on seasons panel"""
        self._focused_panel = "seasons"
        self["status"].setText("Seasons panel selected - Use UP/DOWN to select season")
        # Visual feedback would require custom renderer

    def focus_right(self):
        """Focus on episodes panel"""
        self._focused_panel = "episodes"
        self["status"].setText("Episodes panel selected - Use UP/DOWN to select episode")

    def on_play(self):
        """Play selected episode"""
        if self._focused_panel != "episodes":
            self.focus_right()
            
        sel = self["episode_list"].getCurrent()
        if not sel:
            self["status"].setText("No episode selected")
            return
        
        episode_name, episode = sel[0], sel[1]
        self["status"].setText("Loading: {}".format(episode_name))
        
        try:
            stream_url = None
            stype = self.server.get("type")
            
            if stype == SERVER_TYPE_XTREAM:
                stream_id = episode.get("stream_id", episode.get("id", ""))
                if stream_id:
                    host = self.server.get("host", "")
                    port = self.server.get("port", 8080)
                    username = self.server.get("username", "")
                    password = self.server.get("password", "")
                    scheme = "https" if self.server.get("use_https", False) else "http"
                    base_url = "{}://{}:{}".format(scheme, host, port)
                    stream_url = "{}/series/{}/{}/{}.mp4".format(
                        base_url, username, password, stream_id
                    )
                    
            elif stype == SERVER_TYPE_STALKER:
                cmd = episode.get("cmd", "")
                if cmd:
                    stream_url = self._api.create_series_link(cmd)
                    
            if stream_url:
                if stream_url.startswith("ffmpeg "):
                    stream_url = stream_url.replace("ffmpeg ", "").strip()
                self.session.open(PlayerScreen, stream_url, episode_name, "")
            else:
                self["status"].setText("Cannot play: URL not found")
                
        except Exception as e:
            self["status"].setText("Error: {}".format(str(e)[:40]))

    def _show_error_deferred(self, msg):
        """Show error message"""
        self["status"].setText("ERROR")
        self._error_timer = eTimer()
        self._error_timer.callback.append(lambda: self._show_message_box(msg))
        self._error_timer.start(100, True)

    def _show_message_box(self, msg):
        self.session.open(MessageBox, "Error:\n" + msg,
                          MessageBox.TYPE_ERROR, timeout=5)

    def on_back(self):
        self.close()