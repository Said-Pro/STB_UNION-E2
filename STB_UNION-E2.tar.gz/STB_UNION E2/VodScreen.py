#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# STB_UNION E2 - VOD Screen
#

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.MenuList import MenuList
from enigma import eTimer

from .ServerConfig import SERVER_TYPE_STALKER, SERVER_TYPE_XTREAM
from .PlayerScreen import PlayerScreen


class VodScreen(Screen):
    """VOD Movies browser"""

    PAGE_SIZE = 15

    skin = """
        <screen name="VodScreen" position="0,0" size="1920,1080"
                flags="wfNoBorder" backgroundColor="#000000">
            <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/STB_UNION E2/skin/ChLive.png"
                     position="0,0" size="1920,1080" zPosition="-1" transparent="1"/>
            <widget name="title" position="100,200" size="420,80"
                    font="Regular;36" foregroundColor="#ffdd00"
                    backgroundColor="transparent" halign="center" zPosition="2" transparent="1"/>
            <widget name="vod_list" position="730,180" size="460,525"
                    scrollbarMode="showOnDemand" backgroundColor="#0a0060"
                    foregroundColor="#ffffff" font="Regular;22"
                    itemHeight="35" zPosition="2" transparent="1"/>
            <widget name="page_info" position="730,750" size="460,36"
                    font="Regular;20" foregroundColor="#ffdd00"
                    backgroundColor="transparent" halign="center" zPosition="2" transparent="1"/>
            <widget name="status" position="1300,200" size="580,40"
                    font="Regular;28" foregroundColor="#10e02f"
                    backgroundColor="transparent" halign="center" valign="center"
                    zPosition="2" transparent="1"/>
            <widget name="hint_bar" position="0,1042" size="1920,38"
                    font="Regular;18" foregroundColor="#888888"
                    backgroundColor="transparent" halign="center" zPosition="2" transparent="1"/>
             <widget name="bottom_Live_TV" position="280,980" size="200,40"
                    font="Regular;30" foregroundColor="#fffb00"
                    backgroundColor="transparent" halign="center" valign="center"
                    zPosition="3" transparent="1"/>
            <widget name="bottom_VOD" position="860,980" size="200,40"
                    font="Regular;30" foregroundColor="#11de0d"
                    backgroundColor="transparent" halign="center" valign="center"
                    zPosition="3" transparent="1"/>
            <widget name="bottom_SERIES" position="1440,980" size="200,40"
                    font="Regular;30" foregroundColor="#0004ff"
                    backgroundColor="transparent" halign="center" valign="center"
                    zPosition="3" transparent="1"/>        
        </screen>
    """

    def __init__(self, session, config, server, vod_list):
        Screen.__init__(self, session)
        self.session = session
        self.config = config
        self.server = server
        self._all_vods = vod_list
        self._current_page = 0
        self._total_pages = max(1, -(-len(vod_list) // self.PAGE_SIZE))
        self._api = None

        self["title"] = Label("VOD - Movies")
        self["vod_list"] = MenuList([])
        self["page_info"] = Label("")
        self["status"] = Label("")
        self["bottom_Live_TV"] = Label("LIVE TV")
        self["bottom_VOD"] = Label("VOD")
        self["bottom_SERIES"] = Label("SERIES")
        self["hint_bar"] = Label("UP/DOWN=Navigate  OK=Play  EXIT=Back")

        self["actions"] = ActionMap(
            ["OkCancelActions", "DirectionActions", "ChannelSelectBaseActions"],
            {
                "ok": self.on_play,
                "cancel": self.on_back,
                "up": self.nav_up,
                "down": self.nav_down,
                "nextBouquet": self.next_page,
                "prevBouquet": self.prev_page,
            }, -1
        )

        self.onLayoutFinish.append(self._show_page)
        self._init_api()

    def _init_api(self):
        stype = self.server.get("type")
        if stype == SERVER_TYPE_STALKER:
            from .StalkerAPI import StalkerAPI
            self._api = StalkerAPI(self.server)
            if not self._api.token and self.server.get("token"):
                self._api.token = self.server.get("token")
        else:
            from .XtreamAPI import XtreamAPI
            self._api = XtreamAPI(self.server)

    def _get_page_items(self, page):
        start = page * self.PAGE_SIZE
        end = start + self.PAGE_SIZE
        return self._all_vods[start:end]

    def _show_page(self, select_index=0):
        items = self._get_page_items(self._current_page)
        display_items = []
        for item in items:
            name = item.get("name", item.get("title", "Unknown"))
            display_items.append((name, item))
        self["vod_list"].setList(display_items)
        if display_items:
            self["vod_list"].setCurrentIndex(min(select_index, len(display_items) - 1))
        self._update_status()
        self["page_info"].setText(
            "Page {}/{}  ({} movies)".format(
                self._current_page + 1, self._total_pages, len(self._all_vods)
            )
        )

    def next_page(self):
        if self._current_page < self._total_pages - 1:
            self._current_page += 1
            self._show_page(0)

    def prev_page(self):
        if self._current_page > 0:
            self._current_page -= 1
            self._show_page(0)

    def nav_up(self):
        idx = self["vod_list"].getCurrentIndex()
        if idx > 0:
            self["vod_list"].setCurrentIndex(idx - 1)
            self._update_status()

    def nav_down(self):
        idx = self["vod_list"].getCurrentIndex()
        last = len(self["vod_list"].list) - 1
        if idx < last:
            self["vod_list"].setCurrentIndex(idx + 1)
            self._update_status()

    def _update_status(self):
        sel = self["vod_list"].getCurrent()
        if sel:
            self["status"].setText(sel[0])

    def on_play(self):
        sel = self["vod_list"].getCurrent()
        if not sel:
            return

        title, item = sel[0], sel[1]
        self["status"].setText("Loading: {}".format(title))

        try:
            stream_url = None
            stype = self.server.get("type")

            if stype == SERVER_TYPE_STALKER:
                cmd = item.get("cmd", "")
                if cmd:
                    stream_url = self._api.create_vod_link(cmd)
            else:  # XTREAM
                stream_id = item.get("stream_id", item.get("id", ""))
                ext = item.get("container_extension", "mp4")
                if stream_id:
                    host = self.server.get("host", "")
                    port = self.server.get("port", 8080)
                    username = self.server.get("username", "")
                    password = self.server.get("password", "")
                    scheme = "https" if self.server.get("use_https", False) else "http"
                    base_url = "{}://{}:{}".format(scheme, host, port)
                    stream_url = "{}/movie/{}/{}/{}.{}".format(
                        base_url, username, password, stream_id, ext
                    )

            if stream_url:
                if stream_url.startswith("ffmpeg "):
                    stream_url = stream_url.replace("ffmpeg ", "").strip()
                self.session.open(PlayerScreen, stream_url, title, "")
            else:
                self["status"].setText("Cannot play: URL not found")

        except Exception as e:
            self["status"].setText("Error: {}".format(str(e)[:40]))

    def on_back(self):
        self.close()