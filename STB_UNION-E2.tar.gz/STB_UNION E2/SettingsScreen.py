#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# STB_UNION E2 - Settings Screen
#

from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.config import (ConfigSubsection, ConfigText, ConfigInteger,
                                ConfigSelection, getConfigListEntry)
from Components.ConfigList import ConfigListScreen


class SettingsScreen(ConfigListScreen, Screen):
    skin = """
        <screen name="SettingsScreen" position="0,0" size="1920,1080"
                flags="wfNoBorder" backgroundColor="transparent">
                
            <!-- Background image -->
            <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/STB_UNION E2/skin/1Settings.png"
                     position="0,0" size="1920,1080" zPosition="-1" transparent="1"/>
            
            <!-- Title -->
            <widget name="title" position="100,150" size="420,80"
                    font="Regular;42" foregroundColor="#ffdd00"
                    backgroundColor="transparent" halign="center" zPosition="2" transparent="1"/>
            
            <!-- Config List -->
            <widget name="config" position="300,280" size="1320,520"
                    scrollbarMode="showOnDemand" backgroundColor="#0a0060"
                    foregroundColor="#ffffff" font="Regular;24"
                    itemHeight="45" zPosition="2" transparent="1"/>
            
            <!-- Hint/Info bar -->
            <widget name="hint" position="300,820" size="1320,60"
                    font="Regular;20" foregroundColor="#ffdd00"
                    backgroundColor="transparent" halign="center" zPosition="2" transparent="1"/>
            
            <!-- Bottom Navigation Buttons -->
            <widget name="btn_save" position="300,980" size="300,60"
                    font="Regular;28" foregroundColor="#ffffff"
                    backgroundColor="#2ecc71" halign="center" valign="center"
                    zPosition="3" transparent="0"/>
            <widget name="btn_cancel" position="1320,980" size="300,60"
                    font="Regular;28" foregroundColor="#ffffff"
                    backgroundColor="#e74c3c" halign="center" valign="center"
                    zPosition="3" transparent="0"/>
        
        </screen>
    """

    def __init__(self, session, config):
        Screen.__init__(self, session)
        self.ext_config = config
        settings = config.get("settings", {})

        self.cfg = ConfigSubsection()
        
        # Connection timeout
        self.cfg.timeout = ConfigInteger(
            default=int(settings.get("timeout", 15)), limits=(5, 60))
        
        # User agent
        self.cfg.user_agent = ConfigText(
            default=settings.get("user_agent",
                "Mozilla/5.0 (QtEmbedded; U; Linux; C)"),
            fixed_size=False)
        
        # Player type selection
        # 4097 = GStreamer (default Enigma2)
        # 5001 = ExtePlayer3 (external player)
        # 5002 = ServiceApp (requires ServiceApp plugin)
        self.cfg.player_type = ConfigSelection(
            choices=[
                ("4097", "GStreamer (Default)"),
                ("5001", "ExtePlayer3"),
                ("5002", "ServiceApp")
            ],
            default=settings.get("player_type", "4097")
        )
        
        # Buffer size for streaming
        self.cfg.buffer_size = ConfigInteger(
            default=int(settings.get("buffer_size", 2048)), limits=(512, 8192))

        list_entries = [
            getConfigListEntry("Player Type:", self.cfg.player_type),
            getConfigListEntry("Connection Timeout (s):", self.cfg.timeout),
            getConfigListEntry("Buffer Size (KB):", self.cfg.buffer_size),
            getConfigListEntry("User Agent:", self.cfg.user_agent),
        ]

        ConfigListScreen.__init__(self, list_entries, session=session)

        # Widgets
        self["title"] = Label("")
        self["hint"] = Label("OK = Save   |   CANCEL = Abort   |   Player Type: 4097=GStreamer, 5001=ExtePlayer3, 5002=ServiceApp")
        self["btn_save"] = Label("SAVE")
        self["btn_cancel"] = Label("CANCEL")
        self["button_hint"] = Label("GREEN = Save  |  RED = Cancel")

        
        self["actions"] = ActionMap(
            ["OkCancelActions", "ColorActions"],
            {
                "ok": self.on_save,
                "cancel": self.on_cancel,
                "red": self.on_cancel,
                "green": self.on_save,
            }, -1
        )

    def on_save(self):
        self.ext_config["settings"]["timeout"] = self.cfg.timeout.value
        self.ext_config["settings"]["user_agent"] = self.cfg.user_agent.value.strip()
        self.ext_config["settings"]["player_type"] = self.cfg.player_type.value
        self.ext_config["settings"]["buffer_size"] = self.cfg.buffer_size.value
        self.close(self.ext_config)

    def on_cancel(self):
        self.close(None)