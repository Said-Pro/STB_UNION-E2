#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# STB_UNION E2 - Server Configuration Manager
#

import json
import os

CONFIG_PATH = "/etc/enigma2/STB_UNION_servers.json"

SERVER_TYPE_STALKER = "stalker"
SERVER_TYPE_XTREAM  = "xtream"

DEFAULT_CONFIG = {
    "servers": [],
    "last_server": None,
    "settings": {
        "user_agent": "Mozilla/5.0 (QtEmbedded; U; Linux; C)",
        "timeout": 15,
        "aspect_ratio": "16:9"
    }
}


def load_config():
    if os.path.exists(CONFIG_PATH):
        try:
            with open(CONFIG_PATH, "r") as f:
                data = json.load(f)
                # merge with defaults for new keys
                for k, v in DEFAULT_CONFIG.items():
                    if k not in data:
                        data[k] = v
                return data
        except Exception:
            pass
    return dict(DEFAULT_CONFIG)


def save_config(config):
    try:
        with open(CONFIG_PATH, "w") as f:
            json.dump(config, f, indent=2)
        return True
    except Exception as e:
        print("[STB_UNION] save_config error:", e)
        return False


def add_server(config, server_dict):
    """Add or update a server entry. Returns updated config."""
    servers = config.get("servers", [])
    # Check for duplicate name
    for i, s in enumerate(servers):
        if s.get("name") == server_dict.get("name"):
            servers[i] = server_dict
            config["servers"] = servers
            return config
    servers.append(server_dict)
    config["servers"] = servers
    return config


def remove_server(config, server_name):
    config["servers"] = [s for s in config.get("servers", []) if s.get("name") != server_name]
    if config.get("last_server") == server_name:
        config["last_server"] = None
    return config


def make_stalker_server(name, url, mac, timezone="Europe/Paris"):
    return {
        "type": SERVER_TYPE_STALKER,
        "name": name,
        "url": url.rstrip("/"),
        "mac": mac,
        "timezone": timezone,
        "token": None,
        "expires": None,
    }


def make_xtream_server(name, host, port, username, password, use_https=False):
    scheme = "https" if use_https else "http"
    base_url = "{}://{}:{}".format(scheme, host.rstrip("/"), port)
    return {
        "type": SERVER_TYPE_XTREAM,
        "name": name,
        "host": host,
        "port": int(port),
        "username": username,
        "password": password,
        "base_url": base_url,
        "use_https": use_https,
    }