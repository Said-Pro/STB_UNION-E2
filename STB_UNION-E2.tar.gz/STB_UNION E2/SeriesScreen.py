#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# STB_UNION E2- Series Screen
#

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.MenuList import MenuList
from enigma import eTimer

from .ServerConfig import SERVER_TYPE_STALKER, SERVER_TYPE_XTREAM


class SeriesScreen(Screen):
    """TV Series browser"""

    PAGE_SIZE = 15

    skin = """      
        <screen name="SeriesScreen" position="0,0" size="1920,1080"
                flags="wfNoBorder" backgroundColor="#1a0099">
            <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/STB_UNION E2/skin/ChLive.png"
                     position="0,0" size="1920,1080" zPosition="-1" transparent="1"/>
            <widget name="title" position="100,200" size="420,80"
                    font="Regular;36" foregroundColor="#ffdd00"
                    backgroundColor="transparent" halign="center" zPosition="2" transparent="1"/>
            
            <widget name="series_list" position="730,200" size="460,588"
                    scrollbarMode="showOnDemand" 
                    backgroundColor="#0a0060" foregroundColor="#ffffff"
                    font="Regular;22" itemHeight="35" zPosition="2" transparent="1"/>
        
            <widget name="page_info" position="730,750" size="460,36"
                    font="Regular;20" foregroundColor="#ffdd00"
                    backgroundColor="transparent" halign="center" zPosition="2" transparent="1"/>
            <widget name="status" position="1300,200" size="580,40"
                    font="Regular;28" foregroundColor="#10e02f"
                    backgroundColor="transparent" halign="center" valign="center"
                    zPosition="2" transparent="1"/>
            <widget name="hint_bar" position="0,1042" size="1920,38"
                    font="Regular;18" foregroundColor="#888888"
                    backgroundColor="transparent" halign="center" zPosition="2" transparent="1"/>
            <widget name="bottom_Live_TV" position="280,980" size="200,40"
                    font="Regular;30" foregroundColor="#fffb00"
                    backgroundColor="transparent" halign="center" valign="center"
                    zPosition="3" transparent="1"/>
            <widget name="bottom_VOD" position="860,980" size="200,40"
                    font="Regular;30" foregroundColor="#11de0d"
                    backgroundColor="transparent" halign="center" valign="center"
                    zPosition="3" transparent="1"/>
            <widget name="bottom_SERIES" position="1440,980" size="200,40"
                    font="Regular;30" foregroundColor="#0004ff"
                    backgroundColor="transparent" halign="center" valign="center"
                    zPosition="3" transparent="1"/>
        </screen>
    """

    def __init__(self, session, config, server, series_list):
        Screen.__init__(self, session)
        self.session = session
        self.config = config
        self.server = server
        self._all_series = series_list
        self._current_page = 0
        self._total_pages = max(1, -(-len(series_list) // self.PAGE_SIZE))
        self._api = None
        self._error_timer = None

        self["title"] = Label("TV SERIES")
        self["series_list"] = MenuList([])
        self["page_info"] = Label("")
        self["status"] = Label("")
        self["hint_bar"] = Label("UP/DOWN=Navigate  OK=View Seasons/Episodes  RED=Back  EXIT=Close")
        self["bottom_Live_TV"] = Label("LIVE TV")
        self["bottom_VOD"] = Label("VOD")
        self["bottom_SERIES"] = Label("SERIES")

        self["actions"] = ActionMap(
            ["OkCancelActions", "DirectionActions", "ChannelSelectBaseActions", "ColorActions"],
            {
                "ok": self.on_info,
                "cancel": self.on_back,
                "up": self.nav_up,
                "down": self.nav_down,
                "nextBouquet": self.next_page,
                "prevBouquet": self.prev_page,
                "red": self.on_back_to_bouquets,
                "green": self.on_vod,
                "blue": self.on_series,
            }, -1
        )

        self.onLayoutFinish.append(self._show_page)
        self._init_api()

    def _init_api(self):
        """Initialize API"""
        stype = self.server.get("type")
        if stype == SERVER_TYPE_STALKER:
            from .StalkerAPI import StalkerAPI
            self._api = StalkerAPI(self.server)
            if not self._api.token and self.server.get("token"):
                self._api.token = self.server.get("token")
        else:
            from .XtreamAPI import XtreamAPI
            self._api = XtreamAPI(self.server)

    def _get_page_items(self, page):
        start = page * self.PAGE_SIZE
        end = start + self.PAGE_SIZE
        return self._all_series[start:end]

    def _show_page(self, select_index=0):
        items = self._get_page_items(self._current_page)
        display_items = []
        for item in items:
            name = item.get("name", item.get("title", "Unknown Series"))
            display_items.append((name, item))
        self["series_list"].setList(display_items)
        if display_items:
            self["series_list"].setCurrentIndex(min(select_index, len(display_items) - 1))
        self._update_status()
        self["page_info"].setText(
            "Page {}/{}  ({} series)".format(
                self._current_page + 1, self._total_pages, len(self._all_series)
            )
        )

    def next_page(self):
        if self._current_page < self._total_pages - 1:
            self._current_page += 1
            self._show_page(0)

    def prev_page(self):
        if self._current_page > 0:
            self._current_page -= 1
            self._show_page(0)

    def nav_up(self):
        idx = self["series_list"].getCurrentIndex()
        if idx > 0:
            self["series_list"].setCurrentIndex(idx - 1)
            self._update_status()

    def nav_down(self):
        idx = self["series_list"].getCurrentIndex()
        last = len(self["series_list"].list) - 1
        if idx < last:
            self["series_list"].setCurrentIndex(idx + 1)
            self._update_status()

    def _update_status(self):
        sel = self["series_list"].getCurrent()
        if sel:
            self["status"].setText(sel[0])

    def on_info(self):
        """Show series seasons and episodes"""
        sel = self["series_list"].getCurrent()
        if not sel:
            return
        
        title, series = sel[0], sel[1]
        
        # Get series ID (different for each API type)
        series_id = series.get("series_id", series.get("id"))
        
        if not series_id:
            self._show_error_deferred("Cannot identify series ID")
            return
        
        self["status"].setText("Loading seasons for {}...".format(title))
        
        try:
            # Open season screen
            from .SeasonScreen import SeasonScreen
            self.session.open(SeasonScreen, self.config, self.server, title, series_id, self._api)
        except Exception as e:
            print("[STB_UNION E2] Error opening seasons: {}".format(e))
            self._show_error_deferred("Error: {}".format(str(e)))

    def on_back_to_bouquets(self):
        """Red button - Back to bouquets"""
        if self._error_timer:
            self._error_timer.stop()
        from .BouqScreen import BouqScreen
        self.session.open(BouqScreen, self.config, self.server)

    def on_vod(self):
        """Green button - Go to VOD"""
        if self._error_timer:
            self._error_timer.stop()
        
        self["status"].setText("Loading VOD...")
        
        try:
            stype = self.server.get("type")
            
            if stype == SERVER_TYPE_XTREAM:
                vod_list = self._api.get_vod_streams()
                if vod_list:
                    from .VodScreen import VodScreen
                    self.session.open(VodScreen, self.config, self.server, vod_list)
                else:
                    self._show_error_deferred("No VOD content found")
            elif stype == SERVER_TYPE_STALKER:
                vod_list, total = self._api.get_vod_list()
                if vod_list:
                    from .VodScreen import VodScreen
                    self.session.open(VodScreen, self.config, self.server, vod_list)
                else:
                    self._show_error_deferred("No VOD content found")
            else:
                self._show_error_deferred("Unsupported server type for VOD")
        except Exception as e:
            print("[STB_UNION E2] Error loading VOD: {}".format(e))
            self._show_error_deferred("VOD error: {}".format(str(e)))

    def on_series(self):
        """Blue button - Refresh series (already here)"""
        pass

    def _show_error_deferred(self, msg):
        """Show error message"""
        self["status"].setText("ERROR")
        self._error_timer = eTimer()
        self._error_timer.callback.append(lambda: self._show_message_box(msg))
        self._error_timer.start(100, True)

    def _show_message_box(self, msg):
        self.session.open(MessageBox, "Error:\n" + msg,
                          MessageBox.TYPE_ERROR, timeout=5)

    def on_back(self):
        self.close()